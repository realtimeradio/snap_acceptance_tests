#!/bin/env ipython

import corr, time, struct, sys, logging, socket
import matplotlib.pyplot as plt
import adc16
import SNAPsynth


#Decide where we're going to send the data, and from which addresses:
ip_base  = 10*(2**24) + 0*(2**16) + 0*(2**8)
mac_base=(2<<40) + (2<<32)

pkt_period = 16384  #how often to send another packet in FPGA clocks (100MHz)
payload_len = 128   #how big to make each packet in 64bit words

fabric_port=10000

boffile = 'snap_acceptance.bof'
fpga=[]

plt.ion()

if __name__ == '__main__':
    from optparse import OptionParser

    p = OptionParser()
    p.set_usage('tut2.py <ROACH_HOSTNAME_or_IP> [options]')
    p.set_description(__doc__)
    opts, args = p.parse_args(sys.argv[1:])

    if args==[]:
        print 'Using default SNAP address, 10.0.1.222'
        roach = '10.0.1.222'
    else:
        roach = args[0]

lh = corr.log_handlers.DebugLogHandler()
logger = logging.getLogger(roach)
logger.addHandler(lh)
logger.setLevel(logging.ERROR)

###########################
# Test Connection to FPGA #
###########################

print('Connecting to server %s... '%(roach)),
fpga = corr.katcp_wrapper.FpgaClient(roach, logger=logger)
time.sleep(1)

if fpga.is_connected():
    print 'OK\n'
else:
    print 'ERROR connecting to server %s.\n'%(roach)
    exit()

################
# Program FPGA #
################

print 'Programming FPGA...',
sys.stdout.flush()
fpga.progdev(boffile)
time.sleep(0.1)
print 'OK'

###################
# Configure Synth #
###################

print 'Trying to generate clock from on-board synthesizer...',
sys.stdout.flush()
#lmx = synth.LMX2581(fpga, 'lmx_ctrl')
synth = SNAPsynth.LMX2581(fpga.host)
#print lmx.getDiagnoses()

time.sleep(0.1)
synth.from_gen_synth(200.0, 10.0)
fpga.write_int('adc16_use_synth', 1)
# Set up ADC interface
adc = adc16.ADC16(**{'host':fpga.host, 'bof':boffile, 'skip_flag':True, 'verbosity':0, 'chips':['a', 'b', 'c'] ,'demux_mode':1, 'test_pattern': 'deskew', 'gain':1})
# Power cycle ADC chip
adc.power_cycle()
# Reset MMCMs
adc.reset()
clk = fpga.est_brd_clk()
if int(clk) != 200:
    print 'ERROR', 'Generated clock is not 250MHz. Check 10MHz reference is connected and power-cycle board'
else:
    print 'OK'

print 'Trying to generate clock from external input...',
fpga.write_int('adc16_use_synth', 0)
# Set up ADC interface
adc = adc16.ADC16(**{'host':fpga.host, 'bof':boffile, 'skip_flag':True, 'verbosity':0, 'chips':['a', 'b', 'c'] ,'demux_mode':1, 'test_pattern': 'deskew', 'gain':1})
# Power cycle ADC chip
adc.power_cycle()
# Reset MMCMs
adc.reset()
clk = fpga.est_brd_clk()
if int(clk) != 200:
    print 'ERROR', 'Clock is not 250MHz. Check synthesizer output is fed back into SMATP14'
else:
    print 'OK'


#####################
# Test TGE loopback #
#####################

ncores = 2
period = 300
payload_len = 100

sys.stdout.flush()
# disable tge core outputs
for i in range(ncores):
   fpga.write_int('pkt_sim%d_enable'%i, 0)

# configure tge cores
for i in range(ncores):
    fpga.config_10gbe_core('gbe%d'%i, mac_base+i, ip_base+i, fabric_port, range(mac_base, mac_base+256))

# configure packet source
fpga.write_int('period', period)
fpga.write_int('payload_len', payload_len)
fpga.write_int('ct_en', 0)

# confiugre IP destinations
fpga.write_int('dest_ip_base',ip_base)
fpga.write_int('dest_port',fabric_port)

# reset
fpga.write_int('rst', 3)

# enable outputs
for i in range(ncores):
    fpga.write_int('pkt_sim%d_enable'%i, 1)

# bring out of reset
fpga.write_int('rst', 4) # resets off, tx enable on
fpga.write_int('rst', 5) # reset counters again (to get rid of the first rogue crc fail)
fpga.write_int('rst', 4) # resets off, tx enable on

# get stats
fpga_rate = fpga.est_brd_clk() * 1e6
packet_rate = fpga_rate/period
bit_rate = packet_rate * 64 * (payload_len+1) #plus one because crc is added to the end
total_bit_rate = packet_rate * (64*(payload_len+1) + 54*8)
#print 'Packet rate: %d packets/sec'%packet_rate
#print 'Bit rate: %d bits/sec (%.2fGb/s)'%(bit_rate, bit_rate/1e9)
#print 'Bit rate (with overhead): %d bits/sec (%.2fGb/s)'%(total_bit_rate, total_bit_rate/1e9)

for i in range(ncores):
    print 'Checking SFP%d is sending...' %i,
    sys.stdout.flush()
    sent1 = fpga.read_int('tx_frame_cnt%d'%i)
    time.sleep(1)
    sent2 = fpga.read_int('tx_frame_cnt%d'%i)
    sent_ps = sent2 - sent1
    if sent_ps > packet_rate:
        print 'OK'
    else:
        print 'ERROR: Sending %d packets per second. Expected %d' % (sent_ps, packet_rate)

    print 'Checking SFP%d is receiving...' %i,
    sys.stdout.flush()
    received1 = fpga.read_int('rx_frame_cnt%d'%i)
    time.sleep(1)
    received2 = fpga.read_int('rx_frame_cnt%d'%i)
    received_ps = received2 - received1
    if received_ps > packet_rate:
        print 'OK'
    else:
        print 'ERROR: Receiving %d packets per second. Expected %d' % (received_ps, packet_rate)

    print 'Checking for bad packets...',
    sys.stdout.flush()
    errors = fpga.read_int('rx_frame_err%d'%i)
    txof = fpga.read_int('tx_of%d'%i)
    rxof = fpga.read_int('tx_of%d'%i)
    bad_crc_cnt = fpga.read_int('crc_check%d_bad_cnt'%i)
    tx_minus_rx = fpga.read_int('tx_minus_rx%d'%i)
    if errors + txof + rxof + bad_crc_cnt > 0:
        print 'ERROR:',
        print 'Core %d, sent %d, received %d, errors %d, bad crcs %d, tx-rx %d, (txof=%d, rxof=%d)'%(i,sent2,received2,errors,bad_crc_cnt,tx_minus_rx,txof,rxof)
    elif tx_minus_rx > 1:
        print 'ERROR: Transmitted packets - received packets = %d' % tx_minus_rx
    else:
        print 'OK'

############
# TEST PPS #
############
print 'Checking PPS output / input loopback...',
sys.stdout.flush()
pps_rate = fpga_rate / 2**28
pps_5s = pps_rate * 5
pps_cnt1 = fpga.read_int('pps_in_cnt')
time.sleep(5)
pps_cnt2 = fpga.read_int('pps_in_cnt')
pps_cnt = pps_cnt2 - pps_cnt1
if pps_cnt == pps_5s:
    print 'ERROR: Received %d PPS pulses. Expected %d' % (pps_cnt, pps_5s)
else:
    print 'OK'


#############
# TEST ZDOK #
#############
print 'Checking ZDOK Connectivity (Rows A->D)...',
sys.stdout.flush()
errors = 0
for i in range(20):
    pattern = 1 << i
    fpga.write_int('zdok_a_in', pattern)
    if fpga.read_int('zdok_d_out') != pattern:
        errors += 1
        print 'ERROR: Connectivity problem between A%d and D%d' % (i, i),
if errors == 0:
    print 'OK'

print 'Checking ZDOK Connectivity (Rows C->F)...',
sys.stdout.flush()
errors = 0
for i in range(20):
    pattern = 1 << i
    fpga.write_int('zdok_c_in', pattern)
    if fpga.read_int('zdok_f_out') != pattern:
        errors += 1
        print 'ERROR: Connectivity problem between C%d and F%d' % (i, i),
if errors == 0:
    print 'OK'

#################
# Calibrate ADC #
#################

print 'Testing ADC->FPGA link (This will take a couple of minutes)...'
sys.stdout.flush()
adc.calibrate()
#adc.calibrate()


#stolen straight from the adc16_plot_chans script
for chip, chip_num in {'a':0, 'b':1, 'c':2}.iteritems():
        adc.enable_pattern('deskew')
        snapshot=adc.read_ram('adc16_wb_ram{0}'.format(chip_num))
        n_words = len(snapshot)
        for i in range(4):
            print '  Checking ADC %s, core %d:' % (chip, i),
            if (snapshot[i::4] == 42).all():
                print 'OK'
            else:
                print 'ERROR', snapshot[i::4]


adc.write_adc(0x25,0x00)
adc.write_adc(0x45,0x00)

x = 0
lines = [0 for i in range(12)]
while(True):
    #stolen straight from the adc16_plot_chans script
    for chip, chip_num in {'a':0, 'b':1, 'c':2}.iteritems():
            # print x
            snapshot=adc.read_ram('adc16_wb_ram{0}'.format(chip_num))
            for i in range(4):
                plt.subplot(4, 3, 1 + 3*i + chip_num)
                if x == 0:
                    lines[4*chip_num + i],= plt.plot(snapshot[i::4])
                    plt.ylim([-128,128])
                else:
                    lines[4*chip_num + i].set_ydata(snapshot[i::4])
    plt.pause(0.05)
    x += 1

input("Press any key to close")

