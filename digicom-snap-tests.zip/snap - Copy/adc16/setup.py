from distutils.core import setup

setup(
	name='adc16',
	version='1.0',
	description='HMCAD1511 ADC chip calibration module',
	author='Zuhra Abdurashidova',

)
