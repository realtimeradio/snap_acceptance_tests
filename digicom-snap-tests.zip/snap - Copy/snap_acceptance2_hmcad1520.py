#!/bin/env ipython

import corr, time, struct, sys, logging, socket
import matplotlib.pyplot as plt
import adc16_hmcad1520 as adc16
import SNAPsynth

import logging

CLOCK_MHZ = 200.0

#Decide where we're going to send the data, and from which addresses:
ip_base  = 10*(2**24) + 0*(2**16) + 0*(2**8)
mac_base=(2<<40) + (2<<32)

pkt_period = 16384  #how often to send another packet in FPGA clocks (100MHz)
payload_len = 128   #how big to make each packet in 64bit words

fabric_port=10000

boffile = 'snap_acceptance.bof'
fpga=[]

plt.ion()

if __name__ == '__main__':
    from optparse import OptionParser

    p = OptionParser()
    p.set_usage('tut2.py <ROACH_HOSTNAME_or_IP> [options]')
    p.set_description(__doc__)
    opts, args = p.parse_args(sys.argv[1:])

    if args==[]:
        print 'Using default SNAP address, 10.0.1.222'
        roach = '10.0.1.222'
    else:
        roach = args[0]

lh = corr.log_handlers.DebugLogHandler()
logger = logging.getLogger(roach)
logger.addHandler(lh)
logger.setLevel(logging.ERROR)

###########################
# Test Connection to FPGA #
###########################

print('Connecting to server %s... '%(roach)),
fpga = corr.katcp_wrapper.FpgaClient(roach, logger=logger)
time.sleep(1)

if fpga.is_connected():
    print 'OK\n'
else:
    print 'ERROR connecting to server %s.\n'%(roach)
    exit()

################
# Program FPGA #
################

print 'Programming FPGA...',
sys.stdout.flush()
fpga.progdev(boffile)
time.sleep(0.1)
print 'OK'

###################
# Configure Synth #
###################

print 'Trying to generate clock from on-board synthesizer...',
sys.stdout.flush()
#lmx = synth.LMX2581(fpga, 'lmx_ctrl')
synth = SNAPsynth.LMX2581(fpga.host)
#print lmx.getDiagnoses()

time.sleep(0.1)
synth.from_gen_synth(CLOCK_MHZ, 10.0)
fpga.write_int('adc16_use_synth', 1)
# Set up ADC interface
adc = adc16.ADC16(**{'host':fpga.host, 'bof':boffile, 'skip_flag':True, 'verbosity':0, 'chips':['a', 'b', 'c'] ,'demux_mode':1, 'test_pattern': 'deskew', 'gain':1})
# Set 8-bit mode like HMCAD1511
adc.write_adc(0x53, 0)
# Power cycle ADC chip
adc.power_cycle()
# Reset MMCMs
adc.reset()
clk = fpga.est_brd_clk()
if int(clk) != CLOCK_MHZ:
    print 'Clock appears to be %.1f MHz' % clk
    print 'ERROR', 'Generated clock is not %d MHz. Check 10MHz reference is connected and power-cycle board' % CLOCK_MHZ
else:
    print 'OK'

print 'Trying to generate clock from external input...',
fpga.write_int('adc16_use_synth', 0)
# Set up ADC interface
adc = adc16.ADC16(**{'host':fpga.host, 'bof':boffile, 'skip_flag':True, 'verbosity':0, 'chips':['a', 'b', 'c'] ,'demux_mode':1, 'test_pattern': 'deskew', 'gain':1})

adc.write_adc(0x53, 0)

# Power cycle ADC chip
adc.power_cycle()
# Reset MMCMs
adc.reset()
clk = fpga.est_brd_clk()

if int(clk) != CLOCK_MHZ:
    print 'Clock appears to be %.1f MHz' % clk
    print 'ERROR', 'Clock is not %d MHz. Check synthesizer output is fed back into SMATP14' % CLOCK_MHZ
else:
    print 'OK'




#################
# Calibrate ADC #
#################

print 'Testing ADC->FPGA link (This will take a couple of minutes)...'
sys.stdout.flush()
adc.calibrate(extra_regs={0x53:0})
#adc.calibrate()
print 'ADC calibrated'

#stolen straight from the adc16_plot_chans script
for chip, chip_num in {'a':0, 'b':1, 'c':2}.iteritems():
        adc.enable_pattern('deskew')
        snapshot=adc.read_ram('adc16_wb_ram{0}'.format(chip_num))
        n_words = len(snapshot)
        for i in range(4):
            print '  Checking ADC %s, core %d:' % (chip, i),
            if (snapshot[i::4] == 42).all():
                print 'OK'
            else:
                print 'ERROR', snapshot[i::4]


adc.write_adc(0x25,0x00)
adc.write_adc(0x45,0x00)

x = 0
lines = [0 for i in range(12)]
while(True):
    #stolen straight from the adc16_plot_chans script
    for chip, chip_num in {'a':0, 'b':1, 'c':2}.iteritems():
            # print x
            snapshot=adc.read_ram('adc16_wb_ram{0}'.format(chip_num))
            for i in range(4):
                plt.subplot(4, 3, 1 + 3*i + chip_num)
                if x == 0:
                    lines[4*chip_num + i],= plt.plot(snapshot[i::4])
                    plt.ylim([-128,128])
                else:
                    lines[4*chip_num + i].set_ydata(snapshot[i::4])
    plt.pause(0.05)
    x += 1

input("Press any key to close")

