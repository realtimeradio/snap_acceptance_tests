# SNAPsynth
This is a module for controlling the LMX2581 synthesizer on CASPER SNAP boards.
